from src.interfaces.web_api import router as api_router
from src.interfaces.cli import start_cli
from fastapi import FastAPI
import uvicorn
import threading

app = FastAPI(title="CHATBOTSYS", version="1.0.0")
app.include_router(api_router)

if __name__ == "__main__":
    server_thread = threading.Thread(
        target=uvicorn.run,
        args=(app,),
        kwargs={"host": "0.0.0.0", "port": 8000},
        daemon=True
    )
    server_thread.start()
    start_cli()