import yaml
import os

class Config:
    _instance = None

    def __new__(cls):
        if cls._instance is None:
            cls._instance = super().__new__(cls)
            cls._instance.load_config()
        return cls._instance

    def load_config(self):
        with open("config.yaml") as f:
            self.config = yaml.safe_load(f)
        for key in self.config:
            if env_val := os.getenv(key.upper()):
                self.config[key] = env_val

    def get(self, key, default=None):
        return self.config.get(key, default)