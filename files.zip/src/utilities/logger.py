import logging
import sys
from datetime import datetime
import os

def get_logger(name, log_level="INFO"):
    logger = logging.getLogger(name)
    logger.setLevel(log_level)

    if not logger.handlers:
        # Ensure logs directory exists
        os.makedirs("logs", exist_ok=True)
        console_handler = logging.StreamHandler(sys.stdout)
        console_format = logging.Formatter(
            '%(asctime)s - %(name)s - %(levelname)s - %(message)s')
        console_handler.setFormatter(console_format)

        file_handler = logging.FileHandler(f"logs/chatbot_{datetime.now().strftime('%Y%m%d')}.log")
        file_format = logging.Formatter(
            '%(asctime)s | %(name)s | %(levelname)s | %(message)s')
        file_handler.setFormatter(file_format)

        logger.addHandler(console_handler)
        logger.addHandler(file_handler)
    return logger