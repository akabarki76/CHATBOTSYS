from fastapi import FastAPI, HTTPException, APIRouter
from pydantic import BaseModel
from src.core.conversation import ConversationManager
from src.core.command_parser import CommandParser
from src.core.ai_client import AIClient
from src.utilities.logger import get_logger

logger = get_logger(__name__)
router = APIRouter()

sessions = {}

class ChatRequest(BaseModel):
    message: str
    session_id: str = "default"

@router.post("/chat")
async def chat_endpoint(request: ChatRequest):
    session_id = request.session_id
    if session_id not in sessions:
        sessions[session_id] = {
            "conversation": ConversationManager(),
            "parser": CommandParser(),
            "ai": AIClient()
        }
        sessions[session_id]["conversation"].add_message("system", "You're a helpful assistant")

    conv = sessions[session_id]["conversation"]
    parser = sessions[session_id]["parser"]
    ai = sessions[session_id]["ai"]

    try:
        if command_response := parser.parse(request.message):
            return {"response": command_response}
        conv.add_message("user", request.message)
        ai_response = ai.get_response(conv.get_context())
        conv.add_message("assistant", ai_response)
        return {"response": ai_response}
    except Exception as e:
        logger.error(f"Chat error: {str(e)}")
        raise HTTPException(status_code=500, detail="Internal server error")

@router.post("/reset")
async def reset_session(session_id: str):
    if session_id in sessions:
        sessions[session_id]["conversation"].reset()
        return {"status": "session reset"}
    return {"status": "session not found"}