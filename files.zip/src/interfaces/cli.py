from src.core.conversation import ConversationManager
from src.core.command_parser import CommandParser
from src.core.ai_client import AIClient
from src.utilities.logger import get_logger

logger = get_logger(__name__)

def start_cli():
    print("CHATBOTSYS CLI - Type '/exit' to quit\n")

    conv = ConversationManager()
    parser = CommandParser()
    ai = AIClient()
    conv.add_message("system", "You are a helpful assistant")

    while True:
        try:
            user_input = input("You: ")
            if user_input.lower() in ["/exit", "/quit"]:
                break

            if cmd_response := parser.parse(user_input):
                print(f"Assistant: {cmd_response}")
                continue

            conv.add_message("user", user_input)
            ai_response = ai.get_response(conv.get_context())
            conv.add_message("assistant", ai_response)
            print(f"Assistant: {ai_response}")

        except KeyboardInterrupt:
            print("\nExiting...")
            break
        except Exception as e:
            logger.error(f"CLI error: {str(e)}")
            print("An error occurred. Please try again.")