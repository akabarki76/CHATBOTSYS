import requests
from src.utilities.config_loader import Config

class AIClient:
    def __init__(self):
        config = Config()
        self.api_key = config.get("api_key")
        self.endpoint = config.get("api_endpoint", "https://api.openai.com/v1/chat/completions")

    def get_response(self, messages):
        headers = {"Authorization": f"Bearer {self.api_key}"}
        payload = {
            "model": "gpt-4-turbo",
            "messages": messages,
            "temperature": 0.7
        }
        response = requests.post(self.endpoint, json=payload, headers=headers)
        response.raise_for_status()
        return response.json()["choices"][0]["message"]["content"]