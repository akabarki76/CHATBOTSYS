import requests
from datetime import datetime

class CommandParser:
    def __init__(self):
        self.commands = {
            "weather": self._handle_weather,
            "time": self._handle_time,
            "help": self._handle_help
        }

    def parse(self, user_input: str):
        if user_input.startswith("/"):
            parts = user_input[1:].split(maxsplit=1)
            command = parts[0].lower()
            args = parts[1] if len(parts) > 1 else ""
            if handler := self.commands.get(command):
                return handler(args)
        return None

    def _handle_weather(self, location: str):
        loc = location or "New York"
        try:
            response = requests.get(f"https://wttr.in/{loc}?format=%C+%t")
            return f"Weather in {loc}: {response.text.strip()}"
        except Exception:
            return "Couldn't fetch weather data"

    def _handle_time(self, _):
        return f"Current time: {datetime.now().strftime('%H:%M:%S')}"

    def _handle_help(self, _):
        return "Available commands: " + ", ".join(self.commands.keys())