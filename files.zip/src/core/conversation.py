class ConversationManager:
    def __init__(self, max_history=10):
        self.history = []
        self.max_history = max_history

    def add_message(self, role: str, content: str):
        self.history.append({"role": role, "content": content})
        self._prune_history()

    def _prune_history(self):
        if len(self.history) > self.max_history:
            self.history = [self.history[0]] + self.history[-self.max_history+1:]

    def get_context(self):
        return self.history.copy()

    def reset(self):
        self.history = []